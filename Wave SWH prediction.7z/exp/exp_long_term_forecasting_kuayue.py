import matplotlib;

matplotlib.use('TkAgg')
import pylab
import matplotlib.pyplot as plt
from tqdm import tqdm, trange
from thop import profile
from data_provider.data_factory import data_provider
from exp.exp_basic import Exp_Basic
from utils.tools import EarlyStopping, adjust_learning_rate, visual
from utils.metrics import metric
import torch
import torch.nn as nn
from torch import optim
from tqdm.notebook import tqdm_notebook
import os
import time
import warnings
import numpy as np
from pathlib import Path
import glob
import re

warnings.filterwarnings('ignore')


class Exp_Long_Term_Forecast(Exp_Basic):
    def __init__(self, args):
        super(Exp_Long_Term_Forecast, self).__init__(args)
        path = ""

    def _build_model(self):
        model = self.model_dict[self.args.model].Model(self.args).float()

        if self.args.use_multi_gpu and self.args.use_gpu:
            model = nn.DataParallel(model, device_ids=self.args.device_ids)
        return model

    def _get_data(self, flag):
        data_set, data_loader = data_provider(self.args, flag)
        return data_set, data_loader

    def _select_optimizer(self):
        model_optim = optim.Adam(self.model.parameters(), lr=self.args.learning_rate)
        return model_optim

    def _select_criterion(self):
        criterion = nn.MSELoss()
        return criterion

    def increment_path(path, exist_ok=False, sep='', mkdir=False):
        # Increment file or directory path, i.e. runs/exp --> runs/exp{sep}2, runs/exp{sep}3, ... etc.
        path = Path(path)  # os-agnostic
        if path.exists() and not exist_ok:
            suffix = path.suffix
            path = path.with_suffix('')
            dirs = glob.glob(f"{path}{sep}*")  # similar paths
            matches = [re.search(rf"%s{sep}(\d+)" % path.stem, d) for d in dirs]
            i = [int(m.groups()[0]) for m in matches if m]  # indices
            n = max(i) + 1 if i else 2  # increment number
            path = Path(f"{path}{sep}{n}{suffix}")  # update path
        dir = path if path.suffix == '' else path.parent  # directory
        if not dir.exists() and mkdir:
            dir.mkdir(parents=True, exist_ok=True)  # make directory
        return path

    def vali(self, vali_data, vali_loader, criterion):
        total_loss = []
        self.model.eval()
        with torch.no_grad():
            loop = tqdm(vali_loader, total=len(vali_loader))
            #vali_loader_list = list(vali_loader)
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(loop):
                # for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(vali_loader):
                if i % self.args.pred_len != 0:
                    continue
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float()

                batch_x_mark = batch_x_mark.float().to(self.device)
                batch_y_mark = batch_y_mark.float().to(self.device)

                # decoder input
                dec_inp = torch.zeros_like(batch_y[:, -self.args.pred_len:, :]).float()
                dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], dec_inp], dim=1).float().to(self.device)
                # encoder - decoder
                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        if self.args.output_attention:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)[0]
                        else:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)
                else:
                    if self.args.output_attention:
                        outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)[0]
                    else:
                        if self.args.model == "LSTM" or self.args.model == "CNN_LSTM" or self.args.model == "BPnet" or self.args.model == 'GRU':
                            outputs = self.model(batch_x)
                        else:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)
                f_dim = -1 if self.args.features == 'MS' else 0
                outputs = outputs[:, -self.args.pred_len:, f_dim:]
                batch_y = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)

                pred = outputs.detach().cpu()
                true = batch_y.detach().cpu()

                loss = criterion(pred, true)
                # loop.set_postfix(loss=loss.item(), Steps=i)
                total_loss.append(loss)
        total_loss = np.average(total_loss)
        self.model.train()
        return total_loss

    def train(self, setting):
        train_data, train_loader = self._get_data(flag='train')
        vali_data, vali_loader = self._get_data(flag='val')
        test_data, test_loader = self._get_data(flag='test')

        self.path = os.path.join(self.args.checkpoints,  f'NDBC_1_1_1_256_epoch50_pred{self.args.pred_len}', self.args.data_path,  f"{self.args.model}_{self.args.num}/")
        if not os.path.exists(self.path):
            os.makedirs(self.path)

        time_now = time.time()

        train_steps = len(train_loader)
        early_stopping = EarlyStopping(patience=self.args.patience, verbose=True)

        model_optim = self._select_optimizer()
        criterion = self._select_criterion()

        if self.args.use_amp:
            scaler = torch.cuda.amp.GradScaler()
        loss_value = []
        for epoch in range(self.args.train_epochs):
            iter_count = 0
            train_loss = []

            self.model.train()
            epoch_time = time.time()
            loop = tqdm(train_loader, total=len(train_loader))
            # train_loader_list = list(train_loader)
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(loop):  # 在这儿跨步长？？？
                if i % self.args.pred_len != 0:
                    continue
                iter_count += 1
                model_optim.zero_grad()
                batch_x = batch_x.float().to(self.device)

                batch_y = batch_y.float().to(self.device)
                batch_x_mark = batch_x_mark.float().to(self.device)
                batch_y_mark = batch_y_mark.float().to(self.device)

                # decoder input
                batch_y_pred = torch.zeros_like(batch_y[:, -self.args.pred_len:, :]).float()
                dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], batch_y_pred], dim=1).float().to(self.device)

                # encoder - decoder
                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        if self.args.output_attention:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)[0]
                        else:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)

                        f_dim = -1 if self.args.features == 'MS' else 0
                        outputs = outputs[:, -self.args.pred_len:, f_dim:]
                        batch_y = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)
                        loss = criterion(outputs, batch_y)
                        train_loss.append(loss.item())
                else:
                    if self.args.output_attention:
                        outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)[0]
                    else:
                        if self.args.model == "LSTM" or self.args.model == "CNN_LSTM" or self.args.model == "BPnet" or self.args.model == "GRU":
                            outputs = self.model(batch_x)
                        else:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)

                    f_dim = -1 if self.args.features == 'MS' else 0
                    outputs = outputs[:, -self.args.pred_len:, f_dim:]
                    batch_y = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)
                    loss = criterion(outputs, batch_y)
                    train_loss.append(loss.item())
                # loop.set_description(f'Epoch [{epoch}/{self.args.train_epochs}]')
                # loop.set_postfix(loss=loss.item(), Steps=i)
                # if (i + 1) % 10 == 0:
                # print("\titers: {0}, epoch: {1} | loss: {2:.7f}".format(i + 1, epoch + 1, loss.item()))
                speed = (time.time() - time_now) / iter_count
                left_time = speed * ((self.args.train_epochs - epoch) * train_steps)
                # print('\tspeed: {:.4f}s/iter; left time: {:.4f}s'.format(speed, left_time))
                iter_count = 0
                time_now = time.time()

                if self.args.use_amp:
                    scaler.scale(loss).backward()
                    scaler.step(model_optim)
                    scaler.update()
                else:
                    loss.backward()
                    model_optim.step()

            # print("Epoch: {} cost time: {}".format(epoch + 1, time.time() - epoch_time))
            train_loss = np.average(train_loss)
            loss_value.append(train_loss)
            vali_loss = self.vali(vali_data, vali_loader, criterion)
            test_loss = self.vali(test_data, test_loader, criterion)

            # print("Epoch: {0}, Steps: {1} | Train Loss: {2:.7f} Vali Loss: {3:.7f} Test Loss: {4:.7f}".format(
            #     epoch + 1, train_steps, train_loss, vali_loss, test_loss))
            print("Epoch: {0}, Steps: {1} | Train Loss: {2:.7f}".format(epoch + 1, train_steps, train_loss))
            torch.cuda.synchronize()
            early_stopping(vali_loss, self.model, self.path)
            if early_stopping.early_stop:
                print("Early stopping")
                break

            adjust_learning_rate(model_optim, epoch + 1, self.args)

        # folder_path = path
        # if not os.path.exists(folder_path):
        #     os.makedirs(folder_path)
        plt.figure()
        plt.plot(loss_value, label='loss')
        plt.xlabel('epoch')
        plt.ylabel('values')
        plt.legend(loc='upper right')  # 图例放右上角
        plt.savefig(self.path + 'loss.jpg', dpi=400, bbox_inches='tight')

        best_model_path = self.path + '/' + 'checkpoint.pth'
        self.model.load_state_dict(torch.load(best_model_path))

        return self.model

    def test(self, setting, test=0):
        test_data, test_loader = self._get_data(flag='test')
        if test:
            print('loading model')
            self.model.load_state_dict(
                torch.load(os.path.join(self.path + 'checkpoint.pth')))

        preds = []
        trues = []
        # folder_path = './test_results/' + self.args.data_path + '/' + setting + '/'
        # if not os.path.exists(folder_path):
        #     os.makedirs(folder_path)

        self.model.eval()
        with torch.no_grad():
            #test_loader_list = list(test_loader)
            loop = tqdm(test_loader,total=len(test_loader))
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(loop):
                if i % self.args.pred_len != 0:
                    continue
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)

                batch_x_mark = batch_x_mark.float().to(self.device)
                batch_y_mark = batch_y_mark.float().to(self.device)

                # decoder input
                dec_inp = torch.zeros_like(batch_y[:, -self.args.pred_len:, :]).float()
                dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], dec_inp], dim=1).float().to(self.device)
                # encoder - decoder
                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        if self.args.output_attention:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)[0]
                        else:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)
                else:
                    if self.args.output_attention:
                        outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)[0]

                    else:
                        if self.args.model == "LSTM" or self.args.model == "CNN_LSTM" or self.args.model == "BPnet" or self.args.model == "GRU":
                            outputs = self.model(batch_x)
                        else:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)

                f_dim = -1 if self.args.features == 'MS' else 0
                outputs = outputs[:, -self.args.pred_len:, f_dim:]
                batch_y = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)
                # outputs = outputs[:, -1:, f_dim:]
                # batch_y = batch_y[:, -1:, f_dim:].to(self.device)
                outputs = outputs.detach().cpu().numpy()
                batch_y = batch_y.detach().cpu().numpy()

                pred = outputs
                true = batch_y

                preds.append(pred)
                trues.append(true)

            preds = np.array(preds)
            trues = np.array(trues)
            # trues_last = trues[:, :, -1, :]
            # preds_last = preds[:, :, -1, :]
            # trues_first = trues[:, :, 0, :]
            # preds_first = preds[:, :, 0, :]
            # print('test shape:', preds.shape, trues.shape)
            # preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
            # trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])
            # print('test shape:', preds.shape, trues.shape)

            trues = test_data.inverse_transform(trues.reshape(-1, 1))
            preds = test_data.inverse_transform(preds.reshape(-1, 1))

            # trues_last = test_data.inverse_transform(trues_last.reshape(-1, 1))
            # preds_last = test_data.inverse_transform(preds_last.reshape(-1, 1))
            #
            # trues_first = test_data.inverse_transform(trues_first.reshape(-1, 1))
            # preds_first = test_data.inverse_transform(preds_first.reshape(-1, 1))

            # result save
            # folder_path = f'./results/' + '/'  + f'NDBC_1_1_1_256_epoch50_pred{self.args.pred_len}/'+ self.args.data_path + '/' + setting + '/'
            # folder_path
            # if not os.path.exists(folder_path):
            #     os.makedirs(folder_path)

            mse, rmse, nrmse, mape, mae, mspe, R2, correlation, significance = metric(preds, trues)
            print(f'MSE:{mse:.5f},RMSE:{rmse:.5f}, NRMSE:{nrmse:.5f}, MAPE:{mape:.5f}, MAE:{mae:.5f}, MSPE:{mspe}, R2{R2:.5f}, correlation{correlation:.5f}, significance{significance:.5f}')
            with open(f'./results/' + f'NDBC_1_1_1_256_epoch50_pred{self.args.pred_len}/' +  self.args.data_path + "/" + f'{self.args.data_path}_forecast.txt', 'a') as f:
                f.write(f"{self.args.model},")
                f.write(
                    f'{mse:.5f},{rmse:.5f},{nrmse:.5f},{mape:.5f},{mae:.5f},{mspe},{R2:.5f},{correlation:.5f},{significance:.5f}')
                f.write('\n')
                f.close()

            with open(f'./results/' + f'NDBC_1_1_1_256_epoch50_pred{self.args.pred_len}/' +  self.args.data_path + "/" + f'{self.args.data_path}_forecast.csv', 'a') as f:
                f.write(f"{self.args.model},")
                f.write(f'{mse:.5f},{rmse:.5f},{nrmse:.5f},{mape:.5f},{mae:.5f},{mspe},{R2:.5f},{correlation:.5f},{significance:.5f}')
                f.write('\n')
                f.close()
            trues = trues.reshape(-1)
            preds = preds.reshape(-1)

            plt.figure()
            plt.plot(trues, 'k', label='pre_test_True')
            plt.plot(preds, 'm--', label='pre_test_predict')
            plt.xlabel('t')
            plt.ylabel('values')
            plt.title("test predicted and true values")
            plt.legend(loc='upper right')  # 图例放右上角
            plt.savefig(self.path + 'test predicted and true values.jpg', dpi=400, bbox_inches='tight')
            # print(1)
            # plt.show()
            # print(2)

            # with open(self.path + " result.txt", 'a') as f:
            #     f.write(
            #         f"MSE:{mse:.5f}\n RMSE:{rmse:.5f}\n NRMSE:{nrmse:.5f}\n MAPE:{mape:.5f}\n MAE:{mae:.5f}\n R2:{R2:.5f}\n correlation:{correlation:.5f}\n significance:{significance:.5f}\n")
            np.save(self.path + 'metrics.npy',
                    np.array([mse, rmse, nrmse, mape, mae, mspe, R2, correlation, significance]))
            np.save(self.path + 'pred.npy', preds)
            np.save(self.path + 'true.npy', trues)

            ##first
            # mse, rmse, nrmse, mape, mae, mspe, R2, correlation, significance = metric(preds_first, trues_first)
            # print(
            #     f'MSE:{mse:.5f},RMSE:{rmse:.5f}, NRMSE:{nrmse:.5f}, MAPE:{mape:.5f}, MAE:{mae:.5f}, MSPE:{mspe}, R2{R2:.5f}, correlation{correlation:.5f}, significance{significance:.5f}')
            # with open(f'./results/' + f'NDBC_1_1_1_256_epoch50_pred{self.args.pred_len}/' +  self.args.data_path + f'/{self.args.data_path}_forecast_first.txt', 'a') as f:
            #     f.write(f"{self.args.model},")
            #     f.write(
            #         f'{mse:.5f},{rmse:.5f},{nrmse:.5f},{mape:.5f},{mae:.5f},{mspe},{R2:.5f},{correlation:.5f},{significance:.5f}')
            #     f.write('\n')
            #     f.close()
            #
            # # trues_first = trues_first.reshape(-1)
            # # preds_first = preds_first.reshape(-1)
            #
            # plt.figure()
            # plt.plot(trues_first, 'k', label='pre_test_True')
            # plt.plot(preds_first, 'm--', label='pre_test_predict')
            # plt.xlabel('t')
            # plt.ylabel('values')
            # plt.title("test predicted and true values")
            # plt.legend(loc='upper right')  # 图例放右上角
            # plt.savefig(folder_path + 'test predicted and true values_last.jpg', dpi=400, bbox_inches='tight')
            # plt.show()
            #
            # with open(folder_path + " result_first.txt", 'a') as f:
            #     f.write(
            #         f"MSE:{mse:.5f}\n RMSE:{rmse:.5f}\n NRMSE:{nrmse:.5f}\n MAPE:{mape:.5f}\n MAE:{mae:.5f}\n MSPE:{mspe:.5f}\n R2:{R2:.5f}\n correlation:{correlation:.5f}\n significance:{significance:.5f}\n")
            # np.save(folder_path + 'metrics_first.npy',
            #         np.array([mse, rmse, nrmse, mape, mae, mspe, R2, correlation, significance]))
            # np.save(folder_path + 'pred_first.npy', preds_first)
            # np.save(folder_path + 'true_first.npy', trues_first)
            #
            # ###last
            # mse, rmse, nrmse, mape, mae, mspe, R2, correlation, significance = metric(preds_last, trues_last)
            # print(
            #     f'MSE:{mse:.5f},RMSE:{rmse:.5f}, NRMSE:{nrmse:.5f}, MAPE:{mape:.5f}, MAE:{mae:.5f}, MSPE:{mspe}, R2{R2:.5f}, correlation{correlation:.5f}, significance{significance:.5f}')
            # with open(f'./results/' + f'NDBC_1_1_1_256_epoch50_pred{self.args.pred_len}/' +  self.args.data_path +"/" + f'{self.args.data_path}_forecast_last.txt', 'a') as f:
            #     f.write(f"{self.args.model},")
            #     f.write(
            #         f'{mse:.5f},{rmse:.5f},{nrmse:.5f},{mape:.5f},{mae:.5f},{mspe},{R2:.5f},{correlation:.5f},{significance:.5f}')
            #     f.write('\n')
            #     f.close()
            #
            # trues_last = trues_last.reshape(-1)
            # preds_last = preds_last.reshape(-1)
            #
            # plt.figure()
            # plt.plot(trues_last, 'k', label='pre_test_True')
            # plt.plot(preds_last, 'm--', label='pre_test_predict')
            # plt.xlabel('t')
            # plt.ylabel('values')
            # plt.title("test predicted and true values")
            # plt.legend(loc='upper right')  # 图例放右上角
            # plt.savefig(folder_path + 'test predicted and true values_last.jpg', dpi=400, bbox_inches='tight')
            # plt.show()
            #
            # with open(folder_path + " result_last.txt", 'a') as f:
            #     f.write(
            #         f"MSE:{mse:.5f}\n RMSE:{rmse:.5f}\n NRMSE:{nrmse:.5f}\n MAPE:{mape:.5f}\n MAE:{mae:.5f}\n MSPE:{mspe:.5f}\n R2:{R2:.5f}\n correlation:{correlation:.5f}\n significance:{significance:.5f}\n")
            # np.save(folder_path + 'metrics_last.npy',
            #         np.array([mse, rmse, nrmse, mape, mae, mspe, R2, correlation, significance]))
            # np.save(folder_path + 'pred_last.npy', preds_last)
            # np.save(folder_path + 'true_last.npy', trues_last)

            return
