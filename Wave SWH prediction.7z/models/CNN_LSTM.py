from torch import nn


class Model(nn.Module):
    def __init__(self, configs,):
        super(Model, self).__init__()
        self.input_size = configs.enc_in
        self.output_size = configs.pred_len
        self.hidden_size = configs.d_model
        self.num_layers = configs.e_layers
        self.relu = nn.ReLU(inplace=True)
        self.conv = nn.Sequential(
            nn.Conv1d(in_channels=configs.enc_in, out_channels=configs.enc_in*2, kernel_size=3),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=3, stride=1)
        )
        self.lstm = nn.LSTM(input_size=configs.enc_in*2, hidden_size=configs.d_model, num_layers=configs.e_layers, batch_first=False,
                            dropout=configs.dropout)
        self.fc = nn.Linear(configs.d_model, configs.pred_len)
        #self.softmax = nn.LogSoftmax(dim=1)

    def forward(self, x):
        x = x.permute(0, 2, 1)  # 索引1 和 2交换位置
        x = self.conv(x)
        x = x.permute(0, 2, 1)
        x, _ = self.lstm(x)

        x = self.fc(x)  # 全连接最后预测输出
        return x