from torch import nn


class Model(nn.Module):
    def __init__(self, configs,):
        super(Model, self).__init__()
        self.input_size = configs.enc_in
        self.output_size = configs.pred_len
        self.hidden_size = configs.d_model
        self.num_layers = configs.e_layers

        self.gru = nn.GRU(input_size=configs.enc_in, hidden_size=configs.d_model, num_layers=configs.e_layers, batch_first=False,
                            dropout=configs.dropout)
        self.fc = nn.Linear(configs.d_model, configs.pred_len)
        #self.softmax = nn.LogSoftmax(dim=1)

    def forward(self, x):
        # x is input, size (batch_size, seq_len, input_size)
        # h_0 = torch.zeros(self.num_layers, time_step, self.hidden_size).to(device)
        # c_0 = torch.zeros(self.num_layers, time_step, self.hidden_size).to(device)
        #x = x.permute(0, 2, 1)
        x, _ = self.gru(x)
        #x = x.permute(0, 2, 1)
        # x, _ = self.lstm(x)  # 16层隐藏层，产生16个中间变量 [batich_size,time_step,1] --> [batich_size, time_step, 16] # x is output, size (batch_size, seq_len, hidden_size)
        #x = x[:, -self.output_size:, :]  # 取其中一维， [batich_size, time_step, 16] —-> [batich_size, 1, 16], 到第5维就不具备预测能力了
        x = self.fc(x)  # 全连接最后预测输出
        return x