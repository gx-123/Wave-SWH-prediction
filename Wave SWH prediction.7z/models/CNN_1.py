import torch
from torch import nn


# class Model(nn.Module):
#     def __init__(self, configs, ):
#         super(Model, self).__init__()
#         self.fc1 = nn.Linear(configs.enc_in, configs.d_model)
#         self.fc2 = nn.Linear(configs.d_model, configs.pred_len)
#         self.softmax = nn.LogSoftmax(dim=1)
#
#     def forward(self, x):
#         x = torch.relu(self.fc1(x))
#         x = self.softmax(self.fc2(x))
#         return x
# class Model(nn.Module):
#     def __init__(self, configs):
#         super(Model, self).__init__()
#         self.conv1 = nn.Conv1d(configs.enc_in, configs.d_model, kernel_size=3, padding=1)
#         self.relu = nn.ReLU()
#         self.fc = nn.Linear(configs.d_model, configs.pred_len)
#
#     def forward(self, x):
#         x = x.permute(0, 2, 1)
#         x = self.conv1(x)
#         x = x.permute(0, 2, 1)
#         x = self.relu(x)
#         #x = x.view(x.size(0), -1)
#         x = self.fc(x)
#         return x
#     
class Model(nn.Module):
    def __init__(self, configs):
        super(Model, self).__init__()
        self.cnn1 = nn.Conv1d(configs.enc_in, configs.d_model, kernel_size=3, padding=1)
        self.relu1 = nn.ReLU()
        self.pool1 = nn.MaxPool1d(kernel_size=3, stride=1)

        self.fc = nn.Linear(configs.d_model-2, configs.pred_len)

    def forward(self, x):
        x = x.permute(0, 2, 1)
        x = self.cnn1(x)
        x = x.permute(0, 2, 1)
        x = self.relu1(x)
        x = self.pool1(x)

        #x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x